import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html'
})

export class AppComponent{

    names:string[] = ["s1","s2","s3"];

    ids:number[] = [1,2,3,4,5];

    student = { "id":1 , "name":"s1"};

    students =  [ 
        { "id":1 , "name":"s1" },
        { "id":2 , "name":"s2" },
        { "id":3 , "name":"s3" }

    ];

    m1(){
        this.names = ["s4","s5","s6"];
    }

}