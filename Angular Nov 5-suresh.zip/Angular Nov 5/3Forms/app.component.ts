import { Student } from './student';
import { Component } from "@angular/core";

@Component({
    selector:"app-root",
    templateUrl:"app.component.html"
})
export class AppComponent{
    s = new Student();
    save(){
        console.log(this.s.id);
        console.log(this.s.name);
    }
}
