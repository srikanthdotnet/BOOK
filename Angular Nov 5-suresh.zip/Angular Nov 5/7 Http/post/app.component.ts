import { Student } from './student';
import { Component } from "@angular/core";
import {HttpClient} from "@angular/common/http";
@Component({
    selector:"app-root",
    templateUrl:"app.component.html"
})
export class AppComponent{
    students = [];

    student = new Student();

    constructor(private hc:HttpClient){

    }

    load(){
        this.hc.get("https://basicstudentapp.herokuapp.com/students/getAllStudents").subscribe((data)=>{
            this.students = <any[]>data;
        });
    }

    save(){
        this.hc.post("https://basicstudentapp.herokuapp.com/students/insertStudent",this.student).subscribe((data)=>{
            alert("insertion success");
        },(error)=>{
            alert("insert failed");
        })
    }

    update(){
        this.hc.put("https://basicstudentapp.herokuapp.com/students/updateStudent",this.student).subscribe((data)=>{
            alert("update success");
        },
        (error)=>{
            alert("update failed");
        })
    }

    delete(){
        this.hc.delete( "https://basicstudentapp.herokuapp.com/students/deleteStudent/"+this.student.id ).
        subscribe((data)=>{
            alert("delete success");
        },(error)=>{
            alert("delete failed");
        })
    }

}