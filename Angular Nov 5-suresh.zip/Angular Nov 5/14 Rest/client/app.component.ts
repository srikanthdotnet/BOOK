import { StudentService } from './student.service';
import { Student } from './student';
import { Component } from "@angular/core";

@Component({
    selector:"app-root",
    templateUrl:"app.component.html"
})
export class AppComponent{
    s = new Student();
    constructor(private ss:StudentService){

    }
    save(){
        this.ss.insert(this.s).subscribe((data)=>{
            alert("insert success");
        })
    }

    update(){
        this.ss.update(this.s).subscribe((data)=>{
            alert("update success");
        })
    }
    
    delete(){
        this.ss.delete(this.s).subscribe((data)=>{
            alert("delete success");
        })
    }

    getData(){
        this.ss.getStudentById(this.s).subscribe((data)=>{
            this.s = (<Student[]>data)[0];
        })
    }
}
