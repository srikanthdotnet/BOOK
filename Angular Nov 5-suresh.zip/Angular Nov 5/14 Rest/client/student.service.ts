import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable()
export class StudentService {
    constructor(private httpClient: HttpClient) { }
    insert(data){
        return this.httpClient.post("http://localhost:3000/insertStudent",data);
    }
    update(data){
        return this.httpClient.put("http://localhost:3000/updateStudent/"+data["id"],data);
    }
    delete(data){
        return this.httpClient.delete("http://localhost:3000/deleteStudent/"+data["id"]);
    }

    getAllStudents(){
        return this.httpClient.get("http://localhost:3000/getAllStudents");
    }

    getStudentById(data){
        return this.httpClient.get("http://localhost:3000/getStudentById/"+data["id"]);
    }
}