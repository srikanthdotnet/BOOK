import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { UserLoginComponent } from './user-login.component';
import { UserService } from './user.service';
import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';

const userRules = [
    {path:"login",component:UserLoginComponent}
]

@NgModule({
    imports: [CommonModule,FormsModule,HttpClientModule,RouterModule.forChild(userRules),RouterModule],
    declarations:[UserLoginComponent],
    providers:[UserService]
})
export class UserModule { }
