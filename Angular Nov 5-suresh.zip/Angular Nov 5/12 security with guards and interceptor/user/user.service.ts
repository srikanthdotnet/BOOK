import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable()
export class UserService {
    constructor(private httpClient: HttpClient) { }
    login(data){
        return this.httpClient.post("https://basicstudentapp.herokuapp.com/users/login",data);
    }
}