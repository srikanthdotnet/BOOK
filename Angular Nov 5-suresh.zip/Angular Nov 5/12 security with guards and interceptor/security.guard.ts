import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class SecurityGuard implements CanActivate {
    constructor() { }

    canActivate() {
        let abc = localStorage.getItem("id");
        if(abc!=null)
            return true;
        else
            return false;
    }
}