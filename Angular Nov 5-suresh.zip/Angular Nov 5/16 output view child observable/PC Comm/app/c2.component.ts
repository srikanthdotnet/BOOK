import { Student } from './student';
import { Component, Input , EventEmitter,Output } from '@angular/core';

@Component({
    selector: 'c2',
    templateUrl: 'c2.component.html'
})

export class Component2{
    @Input()
    j:number;

    @Input()
    parentData:Student;

    @Output()
    sendData = new EventEmitter();

    m2(){
        this.j = this.j + 1;
        this.sendData.emit(this.j);
    }
}