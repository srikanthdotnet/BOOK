import { Component2 } from './c2.component';
import { Student } from './student';
import { Component, OnInit, ViewChild,ElementRef,ViewChildren,QueryList } from '@angular/core';

@Component({
    selector: 'c1',
    templateUrl: 'c1.component.html'
})

export class Component1{
    i:number = 10;
    s1:Student = new Student(1,"s1");
    @ViewChild(Component2)
    myChild:Component2;

    @ViewChildren(Component2)
    myChildren:QueryList<Component2>;

    m1(){
        this.i = this.i + 1;
        console.log(this.myChild);
        console.log(this.myChildren);
    }
    accessData(newValue){
        this.i = newValue;
    }
}