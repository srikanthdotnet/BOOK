import { Injectable } from '@angular/core';
import { Subject } from "rxjs";
@Injectable()
export class Service1 {
    data;
    
    dataService= new Subject();
    
    setData(newValue){
        this.data = newValue;
        this.dataService.next(this.data);
    }

    getDataService(){
        return this.dataService.asObservable();
    }
}