import { Service1 } from './s1.service';
import { Component2 } from './c2.component';
import { Student } from './student';
import { Component, OnInit, ViewChild,ElementRef,ViewChildren,QueryList } from '@angular/core';

@Component({
    selector: 'c1',
    templateUrl: 'c1.component.html'
})

export class Component1{
    i:number = 10;

    constructor(private s1:Service1){

    }

    m1(){
        this.i = this.i + 1;
        this.s1.setData(this.i);
    }
}