import { Injectable } from '@angular/core';

@Injectable()
export class Service1 {
    data;
    
    getData(){
        return this.data;
    }
    setData(newValue){
        this.data = newValue;
    }
}