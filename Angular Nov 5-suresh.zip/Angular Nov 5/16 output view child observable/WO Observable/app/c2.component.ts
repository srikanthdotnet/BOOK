import { Service1 } from './s1.service';
import { Component } from '@angular/core';

@Component({
    selector: 'c2',
    templateUrl: 'c2.component.html'
})

export class Component2{
    
    j:number;

    constructor(private s1:Service1){

    }
    
    m2(){
        this.j = this.s1.getData();
    }
}