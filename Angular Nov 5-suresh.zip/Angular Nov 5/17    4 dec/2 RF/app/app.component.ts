import { Student } from './student';
import { Component } from "@angular/core";
import { FormGroup,FormControl,FormBuilder,Validators } from "@angular/forms";
@Component({
    selector:"app-root",
    templateUrl:"app.component.html"
})
export class AppComponent{


    studentForm:FormGroup;

    constructor(private builder: FormBuilder){
        this.studentForm = this.builder.group({
            id: [""],
            name: ["",[Validators.required,Validators.minLength(4)]],
            email: ["",[Validators.required,Validators.email]]});
    }

    save(){
        alert("id value is "+this.studentForm.value);
    }

}