import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'aboutus',
    template: '<h1>About US content</h1>'
})

export class AboutUsComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}