import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'employee-insert',
    template: '<h1>Employee insert content</h1>'
})

export class EmployeeInsertComponent{
    
}