import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'employee-list',
    template: '<h1>Employee list content</h1>'
})

export class EmployeeListComponent{
    
}