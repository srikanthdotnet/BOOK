import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'student-insert',
    template: '<h1>student insert content</h1>'
})

export class StudentInsertComponent{
    
}