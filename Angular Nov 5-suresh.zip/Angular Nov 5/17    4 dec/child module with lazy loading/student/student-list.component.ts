import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'student-list',
    template: '<h1>student list content</h1>'
})

export class StudentListComponent{

}