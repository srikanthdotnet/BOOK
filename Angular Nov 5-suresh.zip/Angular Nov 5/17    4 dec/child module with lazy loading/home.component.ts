import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'home',
    template: '<h1>Home content</h1>'
})

export class HomeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}