import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'contact',
    template: '<h1>contact content</h1>'
})

export class ContactComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}