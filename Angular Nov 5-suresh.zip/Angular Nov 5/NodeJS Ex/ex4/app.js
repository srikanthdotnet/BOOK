var express = require("express");
var mongodb = require("mongodb");
var bodyParser = require("body-parser");
var cors = require("cors");

var app = express();

app.use(cors());
app.use(bodyParser.json());

var db;
mongodb.connect("mongodb+srv://student1:student@cluster0-ayjgg.mongodb.net/test?retryWrites=true&w=majority",function(err,client){
    if(err){
        console.log(err);
        return;
    }
    db= client.db("batch37");
})

app.get("/getAllStudents",function(req,resp){
    db.collection("students").find().toArray(function(err,results){
        if(err){
            console.log(err);
            return;
        }
        else{
            resp.send(results);
        } 
    })
});

app.post("/insertStudent",function(req,resp){
    db.collection("students").insert(req.body,function(err,results){
        if(err){
            console.log(err);
            return;
        }
        else{
            resp.send({"msg":"insert success"});
        } 
    })
});

app.listen(3000);

hackerearth