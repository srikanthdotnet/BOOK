var express = require("express");   // loading the framework

var  app    =  express();       // initialize or start the framework

var students = [{"id":1,"name":"s1"},{"id":2,"name":"s2"}];

app.get("/getAllStudents",function(req,resp){
    resp.send(students);
});

app.listen(8080);

console.log("server started");