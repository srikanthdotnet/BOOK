var mongodb = require("mongodb");

mongodb.connect("mongodb+srv://student1:student@cluster0-ayjgg.mongodb.net/test?retryWrites=true&w=majority",function(err,client){
    if(err){
        console.log(err);
        return;
    }
    var db = client.db("batch37");

    db.collection("students").insert({"id":3,"name":"s3","email":"s3@gmail.com"},function(err,result){
        if(err){
            conosle.log("insertion failed");
            return;
        }
        console.log("insertion success");
    })

    db.collection("students").find().toArray(function(err,results){
        console.log(results);
    })
})