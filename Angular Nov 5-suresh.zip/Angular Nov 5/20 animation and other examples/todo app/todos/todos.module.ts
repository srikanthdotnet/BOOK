import { TodoService } from './todo.service';
import { RouterModule } from '@angular/router';
import { Routes } from '@angular/router';
import { TodoListComponent } from './todo-list.component';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

var todoRules:Routes  = [
    {path:"todoList",component:TodoListComponent}
]

@NgModule({
    imports: [CommonModule,FormsModule,RouterModule.forChild(todoRules),RouterModule],
    declarations:[TodoListComponent],
    providers:[TodoService]
})
export class TODOModule { }
