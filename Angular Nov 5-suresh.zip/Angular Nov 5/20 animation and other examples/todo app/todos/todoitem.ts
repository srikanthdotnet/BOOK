export class TodoItem{
    name:string;
    completed:boolean = false;
}