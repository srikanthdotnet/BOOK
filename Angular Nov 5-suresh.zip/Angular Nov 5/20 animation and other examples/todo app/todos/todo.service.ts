import { TodoItem } from './todoitem';
import { Injectable } from '@angular/core';

@Injectable()
export class TodoService {

    todoListItems:TodoItem[] = [];

    getAllTodoListItems(){
        var data = localStorage.getItem("list");
        if(data!=null){
            this.todoListItems = JSON.parse(data);
        }
        return this.todoListItems;
    }

    addNewItem(data){
        this.todoListItems.push(data);
        this.updateStorage();
        
    }
    private updateStorage(){
        var dataString = JSON.stringify(this.todoListItems);

        localStorage.setItem("list",dataString);
    }

    deleteItem(index){
        this.todoListItems.splice(index,1);
        this.updateStorage();
    }
    
}