import { TodoService } from './todo.service';
import { TodoItem } from './todoitem';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'todo-list',
    templateUrl: 'todo-list.component.html'
})

export class TodoListComponent implements OnInit{
    allTodoTasks:TodoItem[] = [];

    newTask = new TodoItem();

    constructor(private ts:TodoService){

    }

    ngOnInit(): void {
        this.allTodoTasks=this.ts.getAllTodoListItems();        
    }

    add(){
        this.allTodoTasks.push(this.newTask);
        this.ts.addNewItem(this.newTask);
        this.newTask =  new TodoItem();
    }
    delete(index){
        this.allTodoTasks.splice(index,1);
        this.ts.deleteItem(index);
    }
    edit(index){
        this.newTask=this.allTodoTasks[index];
    }
}