import { HomeComponent } from './home.component';
import { TODOModule } from './todos/todos.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes,RouterModule } from "@angular/router";
import { AppComponent } from './app.component';

var appRules:Routes = [
    {path:"home",component:HomeComponent},
    {path:"",component:HomeComponent},
    
]

@NgModule({
    imports: [BrowserModule,TODOModule,RouterModule.forRoot(appRules),RouterModule],
    declarations: [AppComponent,HomeComponent],
    bootstrap: [AppComponent],
})
export class AppModule { }
