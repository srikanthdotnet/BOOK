import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'home',
    template: '<h1>Home Page</h1>'
})

export class HomeComponent{
    
}