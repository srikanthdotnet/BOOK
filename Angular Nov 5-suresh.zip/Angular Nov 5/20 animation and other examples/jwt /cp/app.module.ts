import { TokenInterceptor } from './token.interceptor';
import { HomeComponent } from './home.component';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { UserModule } from './user/user.module';
import { StudentModule } from './student/student.module';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

@NgModule({
    imports: [BrowserModule,StudentModule,UserModule,FormsModule,HttpClientModule,AppRoutingModule,RouterModule],
    declarations: [AppComponent,HomeComponent],
    providers:[
        {
            provide: HTTP_INTERCEPTORS,
            useClass: TokenInterceptor,
            multi: true
          }
    ],
    bootstrap: [AppComponent],
})
export class AppModule { }
