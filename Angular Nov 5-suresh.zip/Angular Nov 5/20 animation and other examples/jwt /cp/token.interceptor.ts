import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
    constructor() {}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        
        if(req.url.indexOf("login")!=-1){
            return next.handle(req); 
        }
        else{
            const headers = req.headers
                .set('access-token', localStorage.getItem("userToken"));
            const authReq = req.clone({ headers });
            return next.handle(authReq);
        }
    }
}