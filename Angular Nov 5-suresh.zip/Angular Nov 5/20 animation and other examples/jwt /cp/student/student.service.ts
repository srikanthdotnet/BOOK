import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable()
export class StudentService {
    constructor(private httpClient: HttpClient) { }
    getAllStudentsData(){
        return this.httpClient.get("http://localhost:3000/student/getAllStudents")
    }
}