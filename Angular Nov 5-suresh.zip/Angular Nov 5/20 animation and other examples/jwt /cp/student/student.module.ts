import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { StudentService } from './student.service';
import { StudentListComponent } from './student-list.component';
import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
var studentRules:Routes = [
    {path:"studentList",component:StudentListComponent}
]
@NgModule({
    imports: [CommonModule,RouterModule.forChild(studentRules),HttpClientModule,RouterModule],
    declarations:[StudentListComponent],
    providers:[StudentService]
})
export class StudentModule { }
