import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable()
export class UserService {
    constructor(private httpClient: HttpClient) { }

    login(data){
        return this.httpClient.post("http://localhost:3000/user/login",data);
    }
    
}