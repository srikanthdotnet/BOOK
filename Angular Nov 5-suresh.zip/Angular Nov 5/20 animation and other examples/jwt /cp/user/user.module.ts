import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { UserService } from './user.service';
import { UserLoginComponent } from './user-login.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes,RouterModule } from "@angular/router";
var userRules:Routes = [
    {path:"login",component:UserLoginComponent}
]

@NgModule({
    imports: [CommonModule,RouterModule.forChild(userRules),FormsModule,HttpClientModule,RouterModule],
    declarations:[UserLoginComponent],
    providers:[UserService]
})
export class UserModule { }
