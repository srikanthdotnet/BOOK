import { UserService } from './user.service';
import { User } from './user';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'user-login',
    templateUrl: 'user-login.component.html'
})

export class UserLoginComponent{
    u = new User();
    constructor(private us:UserService){

    }
    login(){
        this.us.login(this.u).subscribe((data)=>{
            var userData = data["abc"];
            localStorage.setItem("userToken",userData);
            alert("success");
        },(error)=>{
            alert("invalid username and password");
        })
    }
}