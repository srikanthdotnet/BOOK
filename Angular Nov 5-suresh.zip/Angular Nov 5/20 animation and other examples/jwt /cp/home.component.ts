import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'home',
    template: 'home page'
})

export class HomeComponent{}