import { Student } from './student';
import { Component,AfterViewInit,AfterViewChecked } from "@angular/core";

@Component({
    selector:"app-root",
    templateUrl:"app.component.html"
})
export class AppComponent implements AfterViewInit,AfterViewChecked{
    private addStudent(){
        this.students.push({"id": 4, "name": "s4"});
      }
      
      private changeStudents (){
        this.students =[
            {"id": 5, "name": "s5"},
            {"id": 6, "name": "s6"}];
      }
      
      students = [
        {"id": 1, "name": "s1"},
        {"id": 2, "name": "s2"},
        {"id": 3, "name": "s3"},
      ];

      ngAfterViewInit(): void {
          //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
          //Add 'implements AfterViewInit' to the class.
          console.log("ng after view init for app");
      }

      ngAfterViewChecked(): void {
          //Called after every check of the component's view. Applies to components only.
          //Add 'implements AfterViewChecked' to the class.
          console.log("ng after view checked for app");
      }
      

}