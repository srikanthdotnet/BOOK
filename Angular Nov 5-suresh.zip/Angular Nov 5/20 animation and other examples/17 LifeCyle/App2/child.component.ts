import { OnDestroy } from '@angular/core';
import { OnInit,OnChanges,DoCheck } from '@angular/core';
import {Component,ChangeDetectorRef,Input,ChangeDetectionStrategy} from '@angular/core';


@Component({
  selector: 'child',
  templateUrl:"child.component.html",
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ChildComponent implements OnChanges,OnInit,DoCheck,OnDestroy {
  @Input() students =[];
  
  constructor(private cd:ChangeDetectorRef){
    console.log("constructor called");  
  }
  ngOnChanges(changes): void {
      //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
      //Add '${implements OnChanges}' to the class.
      console.log('changes',changes);
  }
  ngOnInit(): void {
      //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
      //Add 'implements OnInit' to the class.
      console.log("init method of child");
  }
  ngDoCheck(changes){
    console.log('Checking for refference changes');
    /*if(this.students.length>3){ // if a new food has been pushed into the array
      this.cd.markForCheck();
    }
    this.cd.detectChanges();*/
  }  
  ngOnDestroy(): void {
      //Called once, before the instance is destroyed.
      //Add 'implements OnDestroy' to the class.
      console.log("destroy method of child");
  }
}