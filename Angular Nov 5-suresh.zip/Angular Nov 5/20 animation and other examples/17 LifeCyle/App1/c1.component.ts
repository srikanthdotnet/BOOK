import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c1',
    templateUrl: 'c1.component.html'
})

export class Component1 implements OnInit {

    i:number  = 10;

    constructor() {
        console.log("i am in constructor");
     }

    ngOnInit() { 
        console.log("i am in init method");
    }

    m1(){
        this.i = this.i + 1 ;
    }

    m2(){
        this.i = this.i - 1 ;
    }
}