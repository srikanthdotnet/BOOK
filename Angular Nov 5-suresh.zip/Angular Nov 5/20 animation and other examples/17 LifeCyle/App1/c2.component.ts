import { Component, OnChanges,Input,SimpleChanges } from '@angular/core';

@Component({
    selector: 'c2',
    templateUrl: 'c2.component.html'
})

export class Component2 implements OnChanges {

    @Input()
    j:number;

    @Input()
    k:number;

    constructor() { }

    ngOnChanges(changes:SimpleChanges) {
        if(changes["j"]){
            console.log("j value changes"+JSON.stringify(changes["j"]));
        }
        if(changes["k"]){
            console.log("k value changes"+JSON.stringify(changes["k"]));
        }
     }
}