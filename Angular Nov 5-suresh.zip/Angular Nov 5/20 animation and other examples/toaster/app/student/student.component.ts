import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'student-list',
    templateUrl: "student.component.html"
})

export class StudentComponent{

}