import { SecurityGuard } from './../security.guard';
import { StudentInsertComponent } from './student-insert.component';
import { HttpClientModule } from '@angular/common/http';
import { StudentService } from './student.service';
import { RouterModule } from '@angular/router';
import { StudentListComponent } from './student-list.component';
import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
const studentRules = [
    {path:"studentList",component:StudentListComponent,canActivate:[SecurityGuard]},
    {path:"studentInsert",component:StudentInsertComponent,canActivate:[SecurityGuard]},
]

@NgModule({
    imports: [CommonModule,RouterModule.forChild(studentRules),HttpClientModule,FormsModule],
    declarations:[StudentListComponent,StudentInsertComponent],
    providers:[StudentService]
})
export class StudentModule { }
