import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from "@angular/common/http";
@Injectable()
export class StudentService {

    constructor(private hc:HttpClient){

    }

    getAllStudents(){
        return this.hc.get("https://basicstudentapp.herokuapp.com/students/getAllStudents");
    }

    insertStudent(data){
        return this.hc.post("https://basicstudentapp.herokuapp.com/students/insertStudent",data);
    }

}