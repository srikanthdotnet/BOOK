export class Student{
    id:number;
    name:string;
    constructor(a,b){
        this.id = a;
        this.name = b;
    }
}