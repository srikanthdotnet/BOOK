import { Student } from './student';
import { Component, Input } from '@angular/core';

@Component({
    selector: 'c2',
    templateUrl: 'c2.component.html'
})

export class Component2{
    @Input()
    j:number;

    @Input()
    parentData:Student;
}