import { Student } from './student';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c1',
    templateUrl: 'c1.component.html'
})

export class Component1{
    i:number = 10;
    s1:Student = new Student(1,"s1");
}