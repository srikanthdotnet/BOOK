import { UserService } from './user.service';
import { User } from './user';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'user-login',
    templateUrl: 'user-login.component.html'
})

export class UserLoginComponent{
    user = new User();
    constructor(private us:UserService){

    }
    login(){
        this.us.login(this.user).subscribe((data)=>{
            alert("login success"+data);
        },(error)=>{
            alert("invalid username or password");
        })
    }
}