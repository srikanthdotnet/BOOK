import { ContactComponent } from './contact.component';
import { AboutComponent } from './about.component';
import { HomeComponent } from './home.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from "@angular/router";
import { AppComponent } from './app.component';

var appRules = [
    { path: "home" , component:HomeComponent},
    { path: "contact" , component:ContactComponent},
    { path: "about" , component:AboutComponent},
]

@NgModule({
    imports: [BrowserModule,RouterModule.forRoot(appRules),RouterModule],
    declarations: [AppComponent,HomeComponent,AboutComponent,ContactComponent],
    bootstrap: [AppComponent],
})
export class AppModule { }
