import { RouterModule } from '@angular/router';
import { StudentListComponent } from './student-list.component';
import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";

const studentRules = [
    {path:"studentList",component:StudentListComponent}
]

@NgModule({
    imports: [CommonModule,RouterModule.forChild(studentRules)],
    declarations:[StudentListComponent]
})
export class StudentModule { }
