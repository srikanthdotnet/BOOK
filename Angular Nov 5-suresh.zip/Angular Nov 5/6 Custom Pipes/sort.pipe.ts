import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'sort'
})

export class SortPipe implements PipeTransform {
    transform(values: any[],param1,param2){
        if(values){
            var sortedValues =  values.sort((obj1,obj2)=>{
                if(param2=="asc")
                    return obj1[param1]-obj2[param1];
                else
                    return obj2[param1]-obj1[param1];
            })
            return sortedValues;
        }
    }
}