import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'reverse'
})

export class ReversePipe implements PipeTransform {
    transform(value: string){

        var data = "";
        for(let i=value.length-1;i>=0;i--){
            data = data + value[i];
        }
        return data;
    }
}