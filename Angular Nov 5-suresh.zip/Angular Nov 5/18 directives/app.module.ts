import { HttpClientModule } from '@angular/common/http';
import { UniqueDirective } from './unique.directive';
import { BasicDirective } from './basic.directive';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

@NgModule({
    imports: [BrowserModule,HttpClientModule],
    declarations: [AppComponent,BasicDirective,UniqueDirective],
    bootstrap: [AppComponent],
})
export class AppModule { }
