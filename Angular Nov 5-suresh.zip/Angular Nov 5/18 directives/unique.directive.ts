import { Directive, ElementRef, HostListener } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Directive({ selector: '[unique]' })
export class UniqueDirective {
    constructor(private hc:HttpClient,private e1:ElementRef) { }

    @HostListener("blur")
    m1(){
        var id = this.e1.nativeElement.value;
        this.hc.get("http://localhost:3000/student/"+id).subscribe((data)=>{
            if((<any[]>data).length==0){
                alert("valid value")
            }
            else
                alert("id already exists");
        })
    }
}