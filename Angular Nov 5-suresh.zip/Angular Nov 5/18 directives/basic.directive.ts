import { Directive,HostListener,ElementRef } from '@angular/core';

@Directive({ selector: '[basic]' })
export class BasicDirective {
    constructor(private e1:ElementRef) { 
        console.log("this is basic directive");
    }

    @HostListener("click")
    m1(){
        alert("we are in m1 method");
        console.log(this.e1)
    }
}