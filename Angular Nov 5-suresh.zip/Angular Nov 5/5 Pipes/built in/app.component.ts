import { Component } from "@angular/core";

@Component({
    selector:"app-root",
    templateUrl:"app.component.html"
})
export class AppComponent{

    message : string = "aBcD";

    price : number = 100;

    value:number = 22/7;

    cdate = new Date();

    student = {"id":1,"name":"s1"};
}