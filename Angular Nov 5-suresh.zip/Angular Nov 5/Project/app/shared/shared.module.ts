import { SessionService } from './session.service';
import { NgModule } from '@angular/core';

@NgModule({
    providers: [SessionService],
})
export class SharedModule { }
