import { HomeComponent } from './home.component';
import { PageNotFoundComponent } from './page-not-found.component';
import { Routes, RouterModule } from '@angular/router';
import { StoreModule } from './store/store.module';
import { OrderModule } from './orders/order.module';
import { ProductsModule } from './products/products.module';
import { UsersModule } from './users/user.module';
import { SharedModule } from './shared/shared.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

const appRoutes:Routes = [
  {path:"",component:HomeComponent},
  {path:"**",component:PageNotFoundComponent}
]

@NgModule({
  declarations: [
    AppComponent,PageNotFoundComponent,HomeComponent
  ],
  imports: [
    BrowserModule,SharedModule,UsersModule,ProductsModule,OrderModule,StoreModule,RouterModule.forRoot(appRoutes),RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
