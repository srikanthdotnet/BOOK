import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from "@angular/common/http";
@Injectable()
export class StudentService {

    constructor(private hc:HttpClient){

    }

    getAllStudents(){
        let httpHeaders = new 	HttpHeaders({
            'access-token' : localStorage.getItem("id")
      });    		  
        let options = {  "headers" : httpHeaders     }; 
        return this.hc.get("url",options);
    }

    insertStudent(data){
        return this.hc.post("https://basicstudentapp.herokuapp.com/students/insertStudent",data);
    }

}